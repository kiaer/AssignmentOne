//
//  A1.c
//  ECG
//
//  Created by Cebrail Erdogan on 11/09/13.
//  Copyright (c) 2013 Cebrail Erdogan. All rights reserved.
//

#include <stdio.h>
