
int QRS();
int documentLength;
double time_spent_pbs;