//
//  derivative.h
//  ECG
//
//  Created by Cebrail Erdogan on 14/09/13.
//  Copyright (c) 2013 Cebrail Erdogan. All rights reserved.
//

#ifndef ECG_derivative_h
#define ECG_derivative_h

int derivative();
void resetDerivative();
double time_spent_der;

#endif
