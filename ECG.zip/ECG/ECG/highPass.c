//
//  highPass.c
//  ECG
//
//  Created by Cebrail Erdogan on 14/09/13.
//  Copyright (c) 2013 Cebrail Erdogan. All rights reserved.
//

#include <stdlib.h>
#include "sensor.h"
#include "lowPass.h"
#include <stdio.h>
#include <time.h>
#include <unistd.h>

int Xn[32];
int Yn_1;
int dataPoint, y;
clock_t end, start;
double time_spent_hpf;

int highPass(){
    
//    start = clock();
    dataPoint = lowPass();
    y =  Yn_1 - (dataPoint/32) + (Xn[15] - Xn[16]) + (Xn[31]/32);
    Yn_1 = y;
    
    for (int i = 31; i > 0; i--) {
        Xn[i] = Xn[i-1];
    }
    Xn[0] = dataPoint;
    
    
    
//    end = clock();
//    time_spent_hpf += (double) (end - start) / CLOCKS_PER_SEC;
    return y;
}

void resetHighPass(){
    for (int i = 0; i < sizeof(Xn); i++) {
        Xn[i] = 0;
    }
    dataPoint= 0;
    Yn_1 = 0;
}

