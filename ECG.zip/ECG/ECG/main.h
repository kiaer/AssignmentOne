//
//  main.h
//  ECG
//
//  Created by Cebrail Erdogan on 28/09/13.
//  Copyright (c) 2013 Cebrail Erdogan. All rights reserved.
//

#ifndef ECG_main_h
#define ECG_main_h

void reset();

#endif
