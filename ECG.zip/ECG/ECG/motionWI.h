//
//  motionWI.h
//  ECG
//
//  Created by Cebrail Erdogan on 15/09/13.
//  Copyright (c) 2013 Cebrail Erdogan. All rights reserved.
//

#ifndef ECG_motionWI_h
#define ECG_motionWI_h

int motionWI();
int resetMotionWindow();
double time_spent_mwi;

#endif
