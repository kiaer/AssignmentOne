void init();

int getNextData(); // Please implement me in Sensor.c

